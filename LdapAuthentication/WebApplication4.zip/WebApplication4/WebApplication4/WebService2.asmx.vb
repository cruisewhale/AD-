﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Data.SqlClient

' 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。
<System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class WebService2
    Inherits System.Web.Services.WebService

    <WebMethod()> _
    Public Function HelloWorld() As String
        Return "Hello World"
    End Function

    <WebMethod()> _
    Public Function MktM() As MRS
        '读取数据的示例  将数据反回的类型定义为MRS--数组，以提供给修改数据的FUNCTION
        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.53;uid=test;pwd=123456;database=ABC")
        Dim objCommand As SqlCommand
        Dim objDataADP As SqlDataAdapter = New SqlDataAdapter("select mk_code,mk_desc from market_m ", objConnection)
        Dim objDS As DataSet = New DataSet

        objConnection.Open()
        objDataADP.Fill(objDS, "market_m")
        Dim i, j As Integer
        Dim mkt As Mktrecord
        j = objDS.Tables(0).Rows.Count
        Dim mktout As New MRS
        ReDim mktout.list(objDS.Tables(0).Rows.Count - 1)

        For i = 0 To objDS.Tables(0).Rows.Count - 1 Step i + 1
            mktout.list(i) = New Mktrecord
            mktout.list(i).code = CType(objDS.Tables(0).Rows(i)("mk_code"), String)
            mktout.list(i).desc = CType(objDS.Tables(0).Rows(i)("mk_desc"), String)
        Next
        Return mktout  ' no errors


    End Function


    <WebMethod()> _
    Public Function MktMupdate(ByVal Record As MRS)
        '数据修改实例，注意 此处定义的 Record AS MRS 与 上面读取数据的示例 返回的类一样，否则将不能正确读取数据。
        '这是因为在读取XML的格式如果与定义的类的格式对应不上，将无法读取数据
        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.53;uid=test;pwd=123456;database=ABC")
        Dim objCommand As SqlCommand
        objConnection.Open()
        Dim A, B As String
        A = Record.list(1).code
        B = Record.list(1).desc

        Dim strStoredProcedure As String = "updatemkt '" & A & " ','" & B & "'" '存储过程名
        Dim strCommandText As String = strStoredProcedure   '存储过程
        objCommand = New SqlCommand(strCommandText, objConnection)
        objCommand.ExecuteNonQuery()
        objConnection.Close()
        Return ""  'mktout    ' no errors

    End Function
    <WebMethod()> _
    Public Function material() As materials
        '读取数据的示例  将数据反回的类型定义为MRS--数组，以提供给修改数据的FUNCTION
        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.53;uid=sy;pwd=123456;database=Android_test")

        Dim strStoredProcedure As String = "ZR_material" '存储过程名

        Dim objDataADP As SqlDataAdapter = New SqlDataAdapter(strStoredProcedure, objConnection)

        Dim objDS As DataSet = New DataSet

        objConnection.Open()
        objDataADP.Fill(objDS, "material1")
        Dim i, j As Integer

        j = objDS.Tables(0).Rows.Count
        Dim mktout As New materials

        ReDim mktout.list(objDS.Tables(0).Rows.Count - 1)

        For i = 0 To objDS.Tables(0).Rows.Count - 1 Step i + 1
            mktout.list(i) = New materialList
            mktout.list(i).code = CType(objDS.Tables(0).Rows(i)("material_num"), String)
            mktout.list(i).desc = CType(objDS.Tables(0).Rows(i)("material_nam"), String)
        Next
        Return mktout  ' no errors


    End Function
    <WebMethod()> _
    Public Function Material2() As materialList()
        '读取数据的示例  将数据反回的类型定义为MRS--数组，以提供给修改数据的FUNCTION
        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.53;uid=sy;pwd=123456;database=Android_test")

        Dim strStoredProcedure As String = "ZR_material" '存储过程名

        Dim objDataADP As SqlDataAdapter = New SqlDataAdapter(strStoredProcedure, objConnection)

        Dim objDS As DataSet = New DataSet

        objConnection.Open()
        objDataADP.Fill(objDS, "material")
        Dim i, j As Integer

        j = objDS.Tables(0).Rows.Count
        Dim mktout(objDS.Tables(0).Rows.Count - 1) As materialList


        'ReDim mktout(objDS.Tables(0).Rows.Count - 1)


        For i = 0 To objDS.Tables(0).Rows.Count - 1 Step i + 1
            mktout(i) = New materialList
            mktout(i).code = CType(objDS.Tables(0).Rows(i)("material_num"), String)
            mktout(i).desc = CType(objDS.Tables(0).Rows(i)("material_nam"), String)
        Next
        Return mktout  ' no errors


    End Function

    <WebMethod()> _
    Public Function getCapexInfo(barcode As String) As capexlist
        '获取一个固定资产信息
        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.53;uid=test;pwd=123456;database=ABC")
        Dim objCommand As SqlCommand
        Dim strSQL As String
        Dim dr As SqlDataReader
        Dim objDS As DataSet = New DataSet
        Dim capexout As New capexlist

        strSQL = "SELECT id,cname,costcenter,dept FROM abc.dbo.capexlist where id=" + barcode
        '================================================================================================

        '建立数据库连接 

        '建立OleDbCommand对象,以便执行SQL指令或获取OleDbDataReader对象
        objCommand = New SqlCommand(strSQL, objConnection)
        objConnection.Open()

        '取得OleDbDataReader对象

        dr = objCommand.ExecuteReader()

        If dr.Read() Then
            capexout.id = dr.Item(0)
            capexout.cname = dr.Item(1)
            capexout.costcenter = dr.Item(2)
            capexout.dept = dr.Item(3)

            If dr.IsDBNull(1) Then
                ' Session("Usr_pwd") = ""
            End If

        Else
            capexout.id = ""
            capexout.cname = ""
            capexout.costcenter = ""
            capexout.dept = ""
        End If

        objConnection.Close()

        Return capexout  ' no errors
    End Function

    <WebMethod()> _
    Public Function getCapexInfos() As capexlist()
        '获取固定资产清单
        Dim strSQL As String

        strSQL = "SELECT id,cname,costcenter,dept FROM abc.dbo.capexlist"
        '================================================================================================

        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.53;uid=sy;pwd=123456;database=abc")

        Dim objDataADP As SqlDataAdapter = New SqlDataAdapter(strSQL, objConnection)

        Dim objDS As DataSet = New DataSet

        objConnection.Open()
        objDataADP.Fill(objDS, "capexlists")
        Dim i, j As Integer

        j = objDS.Tables(0).Rows.Count
        Dim capexout(objDS.Tables(0).Rows.Count - 1) As capexlist

        For i = 0 To objDS.Tables(0).Rows.Count - 1 Step i + 1
            capexout(i) = New capexlist
            capexout(i).id = CType(objDS.Tables(0).Rows(i)("id"), String)
            capexout(i).cname = CType(objDS.Tables(0).Rows(i)("cname"), String)
            capexout(i).costcenter = CType(objDS.Tables(0).Rows(i)("costcenter"), String)
            capexout(i).dept = CType(objDS.Tables(0).Rows(i)("dept"), String)
        Next
        Return capexout  ' no errors

    End Function



    <WebMethod()> _
    Public Function uploadCheckCapexlist(id As String, cname As String, costcenter As String, dept As String, chkdate As String, newcostcenter As String)

        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.53;uid=test;pwd=123456;database=ABC")
        Dim objCommand As SqlCommand
        objConnection.Open()

        Dim strStoredProcedure As String = "uploadcheckcapexlist '" & id & " ','" & cname & "','" & costcenter & " ','" & dept & " ','" & chkdate & " ','" & newcostcenter & "'"  '存储过程名
        Dim strCommandText As String = strStoredProcedure   '存储过程
        objCommand = New SqlCommand(strCommandText, objConnection)
        objCommand.ExecuteNonQuery()
        objConnection.Close()
        Return ""

    End Function

    <WebMethod()> _
    Public Function uploadImage(imgstr As String)

        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.53;uid=test;pwd=123456;database=ABC")
        Dim objCommand As SqlCommand
        objConnection.Open()

        Dim strStoredProcedure As String = "uploadImage N'" & imgstr & "'"  '存储过程名
        Dim strCommandText As String = strStoredProcedure   '存储过程
        objCommand = New SqlCommand(strCommandText, objConnection)
        objCommand.ExecuteNonQuery()
        objConnection.Close()
        Return ""

    End Function
    <WebMethod()> _
    Public Function getImage(id As String) As imglist
        '获取一张图片信息
        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.53;uid=test;pwd=123456;database=ABC")
        Dim objCommand As SqlCommand
        Dim strSQL As String
        Dim dr As SqlDataReader
        Dim objDS As DataSet = New DataSet
        Dim imgout As New imglist

        strSQL = "SELECT * FROM images where id=" + id
        '================================================================================================

        '建立数据库连接 

        '建立OleDbCommand对象,以便执行SQL指令或获取OleDbDataReader对象
        objCommand = New SqlCommand(strSQL, objConnection)
        objConnection.Open()

        '取得OleDbDataReader对象

        dr = objCommand.ExecuteReader()

        If dr.Read() Then
            imgout.id = dr.Item(0)
            imgout.imgstr = dr.Item(1)

            If dr.IsDBNull(1) Then
                ' Session("Usr_pwd") = ""
            End If

        Else
            imgout.id = ""
            imgout.imgstr = ""

        End If

        objConnection.Close()

        Return imgout   ' no errors
    End Function


    <WebMethod()> _
    Public Function getImages() As imglist()
        '获取图片清单
        Dim strSQL As String

        strSQL = "SELECT id,img FROM images "
        '================================================================================================

        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.53;uid=sy;pwd=123456;database=abc")

        Dim objDataADP As SqlDataAdapter = New SqlDataAdapter(strSQL, objConnection)

        Dim objDS As DataSet = New DataSet

        objConnection.Open()
        objDataADP.Fill(objDS, "images")
        Dim i, j As Integer

        j = objDS.Tables(0).Rows.Count
        Dim imgout(objDS.Tables(0).Rows.Count - 1) As imglist

        For i = 0 To objDS.Tables(0).Rows.Count - 1 Step i + 1
            imgout(i) = New imglist
            imgout(i).id = CType(objDS.Tables(0).Rows(i)("id"), String)
            imgout(i).imgstr = CType(objDS.Tables(0).Rows(i)("img"), String)

        Next
        Return imgout  ' no errors
    End Function
End Class
Public Class materialList
    '
    Public code As String
    Public desc As String
End Class
Public Class materials
    '在VB中必须定义数据的界限，否则会出错
    Public list(1) As materialList

End Class


Public Class MRS
    '在VB中必须定义数据的界限，否则会出错
    Public list(1) As Mktrecord
End Class
Public Class Mktrecord
    '
    Public code As String
    Public desc As String
End Class
Public Class capexlist
    '
    Public id As String
    Public cname As String
    Public costcenter As String
    Public dept As String
End Class

Public Class imglist
    Public id As String
    Public imgstr As String
End Class
