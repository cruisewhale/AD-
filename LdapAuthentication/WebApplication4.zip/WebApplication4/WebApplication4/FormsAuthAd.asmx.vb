﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports WebApplication4.FormsAuth          '引入自定义类 LdapAuthentication
Imports WebApplication4.ADusers         ' 引入自定类 resADPassword.vb
Imports System.ServiceProcess



' 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")>
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class FormsAuthAd
    Inherits System.Web.Services.WebService

    <WebMethod()>
    Public Function CheckADuser_CCCIL(user As String, password As String) As String
        '检查帐号密码
        Dim adPath As String = "LDAP://cccil.com/OU=Users,OU=NNCC,OU=CCCIL Bottlers,OU=CCCIL Global,DC=cccil,DC=com" ' Path to your LDAP directory server, 可以通过OU来限制查找范围
        Dim adName As String = "cccil"
        Dim adAut As New LdapAuthentication(adPath)
        Dim result As String
        Try
            '2012/09/03 修正pwd不加Trim，因為密碼有可能會有空字串哦!
            result = adAut.IsAuthenticated(adName, user, password)

        Catch ex As Exception
            '如果驗証失敗會有錯誤訊息
            result = "Denied"
        End Try

        Return result
    End Function

    <WebMethod()>
    Public Function CheckADuser_devIP(user As String, password As String) As String
        '检查帐号密码
        'Dim adPath As String = "LDAP://cccildev.com/OU=Developer,DC=cccildev,DC=com" ' Path to your LDAP directory server, 可以通过OU来限制查找范围
        Dim adPath As String = "LDAP://113.202.45.11/OU=Developer,DC=cccildev,DC=com" ' Path to your LDAP directory server, 可以通过OU来限制查找范围
        Dim adName As String = "cccildev"
        Dim adAut As New LdapAuthentication(adPath)
        Dim result As String
        Try
            '2012/09/03 修正pwd不加Trim，因為密碼有可能會有空字串哦!
            result = adAut.IsAuthenticated(adName, user, password)

        Catch ex As Exception
            '如果驗証失敗會有錯誤訊息
            'result = "Denied"
            result = ex.Message

        End Try

        Return result
    End Function
    <WebMethod()>
    Public Function CheckADuser_dev(user As String, password As String) As String
        '检查帐号密码
        Dim adPath As String = "LDAP://cccildev.com/OU=Developer,DC=cccildev,DC=com" ' Path to your LDAP directory server, 可以通过OU来限制查找范围
        Dim adName As String = "cccildev"
        Dim adAut As New LdapAuthentication(adPath)
        Dim result As String
        Try
            '2012/09/03 修正pwd不加Trim，因為密碼有可能會有空字串哦!
            result = adAut.IsAuthenticated(adName, user, password)

        Catch ex As Exception
            '如果驗証失敗會有錯誤訊息
            'result = "Denied"
            result = ex.Message

        End Try

        Return result
    End Function

    <WebMethod()>
    Public Function resADuserPassword(adUser As String) As Boolean

        '重置AD帐号密码

        Dim adRest As New restADPassword()
        Dim result As Boolean

        Try
            result = adRest.RestPassword(adUser)
        Catch ex As Exception

            result = False

        End Try

        Return result
    End Function



End Class