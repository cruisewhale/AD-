﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Data.SqlClient
Imports System.Data
Imports System.Web

' 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。
<System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class WebService1
    Inherits System.Web.Services.WebService

    '史永平添加
    '测试参数SalSupNum=01005288,SalManNum=01005660,OutNum=501395527,ActID=159
    <WebMethod()> _
    Public Function getDisplaySalesManList_BySalSupNam_test(ByVal SalSupNum As String) As DisplaySalesManList()
        '按主任编号获取待检查业务员清单 55测试机
        '================================================================================================

        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.55;uid=DCDisplayUser;pwd=gx@2014display;database=DC_Display_N")

        Dim strStoredProcedure As String = "Pro_GetSalesManBySalSupMan '" + SalSupNum + "' " '存储过程名

        Dim objDataADP As SqlDataAdapter = New SqlDataAdapter(strStoredProcedure, objConnection)

        Dim objDS As DataSet = New DataSet

        objConnection.Open()

        objDataADP.Fill(objDS, "SalesManlists")

        Dim i, j As Integer

        j = objDS.Tables(0).Rows.Count
        Dim cuslists(objDS.Tables(0).Rows.Count - 1) As DisplaySalesManList

        For i = 0 To objDS.Tables(0).Rows.Count - 1 Step i + 1
            cuslists(i) = New DisplaySalesManList
            cuslists(i).SalManNam = ToStr(objDS.Tables(0).Rows(i)("SalManNam"))
            cuslists(i).SalManNum = ToStr(objDS.Tables(0).Rows(i)("SalManNum"))
            cuslists(i).SalSupNam = ToStr(objDS.Tables(0).Rows(i)("SalSupNam"))
            cuslists(i).SalSupNum = ToStr(objDS.Tables(0).Rows(i)("SalSupNum"))
            cuslists(i).hj = ToStr(objDS.Tables(0).Rows(i)("hj"))
        Next
        Return cuslists ' no errors

    End Function


    '史永平添加 
    '测试参数SalSupNum=01005288,SalManNum=01005660,OutNum=501395527,ActID=159 
    <WebMethod()> _
    Public Function getDisplayOutList_BySalManNam_test(ByVal SalSupNum As String, ByVal SalManNum As String) As DisplayOutList()

        '按主任编号、业代编号获取待检查客户清单 55测试机 
        '================================================================================================ 

        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.55;uid=DCDisplayUser;pwd=gx@2014display;database=DC_Display_N")

        Dim strStoredProcedure As String = "Pro_GetOutBySalesMan '" + SalSupNum + "' ,'" + SalManNum + "'" '存储过程名 

        Dim objDataADP As SqlDataAdapter = New SqlDataAdapter(strStoredProcedure, objConnection)

        Dim objDS As DataSet = New DataSet

        objConnection.Open()

        objDataADP.Fill(objDS, "SalesManlists")

        Dim i, j As Integer

        j = objDS.Tables(0).Rows.Count
        Dim cuslists(objDS.Tables(0).Rows.Count - 1) As DisplayOutList

        For i = 0 To objDS.Tables(0).Rows.Count - 1 Step i + 1
            cuslists(i) = New DisplayOutList
            cuslists(i).SalManNam = ToStr(objDS.Tables(0).Rows(i)("SalManNam"))
            cuslists(i).SalManNum = ToStr(objDS.Tables(0).Rows(i)("SalManNum"))
            cuslists(i).SalSupNam = ToStr(objDS.Tables(0).Rows(i)("SalSupNam"))
            cuslists(i).SalSupNum = ToStr(objDS.Tables(0).Rows(i)("SalSupNum"))
            cuslists(i).OutNam = ToStr(objDS.Tables(0).Rows(i)("OutNam"))
            cuslists(i).OutNum = ToStr(objDS.Tables(0).Rows(i)("OutNum"))
            cuslists(i).hj = ToStr(objDS.Tables(0).Rows(i)("hj"))
        Next
        Return cuslists ' no errors 

    End Function

    '史永平添加
    '测试参数SalSupNum=01005288,SalManNum=01005660,OutNum=501395527,ActID=159
    <WebMethod()> _
    Public Function getDisplayActList_ByOut_test(ByVal SalSupNum As String, ByVal SalManNum As String, ByVal OutNum As String) As DisplayActList()
        '按主任编号、业代编号、客户编号获取待检查客户清单    55测试机
        '================================================================================================

        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.55;uid=DCDisplayUser;pwd=gx@2014display;database=DC_Display_N")

        Dim strStoredProcedure As String = "Pro_GetActByOut  '" + SalSupNum + "' ,'" + SalManNum + "' ,'" + OutNum + "'" '存储过程名

        Dim objDataADP As SqlDataAdapter = New SqlDataAdapter(strStoredProcedure, objConnection)

        Dim objDS As DataSet = New DataSet

        objConnection.Open()

        objDataADP.Fill(objDS, "SalesManlists")

        Dim i, j As Integer

        j = objDS.Tables(0).Rows.Count
        Dim cuslists(objDS.Tables(0).Rows.Count - 1) As DisplayActList

        For i = 0 To objDS.Tables(0).Rows.Count - 1 Step i + 1
            cuslists(i) = New DisplayActList
            cuslists(i).SalManNam = ToStr(objDS.Tables(0).Rows(i)("SalManNam"))
            cuslists(i).SalManNum = ToStr(objDS.Tables(0).Rows(i)("SalManNum"))
            cuslists(i).SalSupNam = ToStr(objDS.Tables(0).Rows(i)("SalSupNam"))
            cuslists(i).SalSupNum = ToStr(objDS.Tables(0).Rows(i)("SalSupNum"))
            cuslists(i).OutNam = ToStr(objDS.Tables(0).Rows(i)("OutNam"))
            cuslists(i).OutNum = ToStr(objDS.Tables(0).Rows(i)("OutNum"))
            cuslists(i).ActNam = ToStr(objDS.Tables(0).Rows(i)("ActNam"))
            cuslists(i).ActID = ToStr(objDS.Tables(0).Rows(i)("ActID"))
        Next
        Return cuslists  ' no errors

    End Function

    '史永平添加
    '测试参数SalSupNum=01005288,SalManNum=01005660,OutNum=501395527,ActID=159
    <WebMethod()> _
    Public Function getDisplayItemList_ByAct_test(ByVal SalSupNum As String, ByVal SalManNum As String, ByVal OutNum As String, ByVal Actid As String) As DisplayItemList()
        '按主任编号、业代编号、客户编号获取待检查客户清单    55测试机
        '================================================================================================

        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.55;uid=DCDisplayUser;pwd=gx@2014display;database=DC_Display_N")

        Dim strStoredProcedure As String = "Pro_GetItemByAct  '" + SalSupNum + "' ,'" + SalManNum + "' ,'" + OutNum + "' ,'" + Actid + "'" '存储过程名

        Dim objDataADP As SqlDataAdapter = New SqlDataAdapter(strStoredProcedure, objConnection)

        Dim objDS As DataSet = New DataSet

        objConnection.Open()

        objDataADP.Fill(objDS, "SalesManlists")

        Dim i, j As Integer

        j = objDS.Tables(0).Rows.Count
        Dim cuslists(objDS.Tables(0).Rows.Count - 1) As DisplayItemList

        For i = 0 To objDS.Tables(0).Rows.Count - 1 Step i + 1
            cuslists(i) = New DisplayItemList
            cuslists(i).ChkDoc = ToStr(objDS.Tables(0).Rows(i)("ChkDoc"))
            cuslists(i).CheckMon = ToStr(objDS.Tables(0).Rows(i)("CheckMon"))
            cuslists(i).SalManNam = ToStr(objDS.Tables(0).Rows(i)("SalManNam"))
            cuslists(i).SalManNum = ToStr(objDS.Tables(0).Rows(i)("SalManNum"))
            cuslists(i).SalSupNam = ToStr(objDS.Tables(0).Rows(i)("SalSupNam"))
            cuslists(i).SalSupNum = ToStr(objDS.Tables(0).Rows(i)("SalSupNum"))
            cuslists(i).OutNam = ToStr(objDS.Tables(0).Rows(i)("OutNam"))
            cuslists(i).OutNum = ToStr(objDS.Tables(0).Rows(i)("OutNum"))
            cuslists(i).ActNam = ToStr(objDS.Tables(0).Rows(i)("ActNam"))
            cuslists(i).ActID = ToStr(objDS.Tables(0).Rows(i)("ActID"))
            cuslists(i).ItemBH = ToStr(objDS.Tables(0).Rows(i)("ItemBH"))
            cuslists(i).ItemDesc = ToStr(objDS.Tables(0).Rows(i)("ItemDesc"))
            cuslists(i).Photo = ToStr(objDS.Tables(0).Rows(i)("Photo"))
            cuslists(i).CreateUser = ToStr(objDS.Tables(0).Rows(i)("CreateUser"))
            cuslists(i).CreateTime = ToStr(objDS.Tables(0).Rows(i)("CreateTime"))

        Next
        Return cuslists  ' no errors

    End Function

    '史永平添加 
    '测试参数SalSupNum=01005288,ChkDoc=2014年GT传统食杂银铜店陈列陈列一-0042-20140429-0001，CheckMon=201405,OutNum=501395527,ActID=159，ItemBH=1/2/3,IsOk=1

    <WebMethod()> _
    Public Function uploadCheck_test(SalSupNum As String, ChkDoc As String, CheckMon As String, OutNum As String, Actid As String, ActNum As String, ItemBH As String, IsOk As String)

        '变更检查项检查结果 55测试机 
        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.55;uid=DCDisplayUser;pwd=gx@2014display;database=DC_Display_N")

        Dim objCommand As SqlCommand
        objConnection.Open()

        Dim strStoredProcedure As String = "Pro_UPdateItemCheck '" + SalSupNum + "','" + ChkDoc + "','" + CheckMon + "','" + OutNum + "','" + Actid + "','" + ActNum + "','" + ItemBH + "','" + IsOk + "'" '存储过程名

        Dim strCommandText As String = strStoredProcedure '存储过程 
        objCommand = New SqlCommand(strCommandText, objConnection)
        objCommand.ExecuteNonQuery()
        objConnection.Close()
        Return ""
    End Function

    '史永平添加 
    '测试参数SalSupNum=01005288,SalManNum=01005660,OutNum=501395527,ActID=159 
    <WebMethod()> _
    Public Function getDisplayItemList_NoPhoto_ByAct_test(ByVal SalSupNum As String, ByVal SalManNum As String, ByVal OutNum As String, ByVal Actid As String) As DisplayActItemListNoPhoto()

        '按主任编号、业代编号、客户编号获取待检查项清单 55测试机 
        '================================================================================================ 

        Dim objConnection As SqlConnection = New SqlConnection("Server=210.76.150.55;uid=DCDisplayUser;pwd=gx@2014display;database=DC_Display_N")

        Dim strStoredProcedure As String = "Pro_GetItemByActNoPhoto '" + SalSupNum + "' ,'" + SalManNum + "' ,'" + OutNum + "' ,'" + Actid + "'" '存储过程名

        Dim objDataADP As SqlDataAdapter = New SqlDataAdapter(strStoredProcedure, objConnection)

        Dim objDS As DataSet = New DataSet

        objConnection.Open()

        objDataADP.Fill(objDS, "SalesManlists")

        Dim i, j As Integer

        j = objDS.Tables(0).Rows.Count
        Dim cuslists(objDS.Tables(0).Rows.Count - 1) As DisplayActItemListNoPhoto

        For i = 0 To objDS.Tables(0).Rows.Count - 1 Step i + 1
            cuslists(i) = New DisplayActItemListNoPhoto
            cuslists(i).ChkDoc = ToStr(objDS.Tables(0).Rows(i)("ChkDoc"))
            cuslists(i).CheckMon = ToStr(objDS.Tables(0).Rows(i)("CheckMon"))
            cuslists(i).SalManNam = ToStr(objDS.Tables(0).Rows(i)("SalManNam"))
            cuslists(i).SalManNum = ToStr(objDS.Tables(0).Rows(i)("SalManNum"))
            cuslists(i).SalSupNam = ToStr(objDS.Tables(0).Rows(i)("SalSupNam"))
            cuslists(i).SalSupNum = ToStr(objDS.Tables(0).Rows(i)("SalSupNum"))
            cuslists(i).OutNam = ToStr(objDS.Tables(0).Rows(i)("OutNam"))
            cuslists(i).OutNum = ToStr(objDS.Tables(0).Rows(i)("OutNum"))
            cuslists(i).ActNum = ToStr(objDS.Tables(0).Rows(i)("ActNum"))
            cuslists(i).ActID = ToStr(objDS.Tables(0).Rows(i)("ActID"))
            cuslists(i).ItemBH = ToStr(objDS.Tables(0).Rows(i)("ItemBH"))
            cuslists(i).ItemDesc = ToStr(objDS.Tables(0).Rows(i)("ItemDesc"))

        Next
        Return cuslists ' no errors 

    End Function





    '史永平添加
    ''' <summary>
    ''' 转化为字符串
    ''' </summary>
    ''' <param name="obj">需要转化的数据</param>
    ''' <returns>如果是DBNULL返回空,否则返回本字符串</returns>
    ''' <remarks></remarks>
    Public Function ToStr(ByVal obj As Object) As String
        If IsDBNull(obj) Then
            Return ""
        Else
            If obj Is Nothing Then
                Return ""
            Else
                Return CType(obj, String)
            End If
        End If
    End Function
End Class


'史永平添加 
Public Class DisplaySalesManList
    '待检查业务员列表 
    Public SalSupNum As String '主任ID 
    Public SalSupNam As String '主任名称 
    Public SalManNum As String '业代ID 
    Public SalManNam As String '业代名称 
    Public hj As String '客户数量 
End Class

'史永平添加 
Public Class DisplayOutList
    '待检查客户列表 
    Public SalSupNum As String '主任ID 
    Public SalSupNam As String '主任名称 
    Public SalManNum As String '业代ID 
    Public SalManNam As String '业代名称 
    Public OutNum As String '客户ID 
    Public OutNam As String '客户名称 
    Public hj As String '活动数量 
End Class

'史永平添加
Public Class DisplayActList
    '待检查客户活动列表
    Public SalSupNum As String  '主任ID
    Public SalSupNam As String  '主任名称
    Public SalManNum As String  '业代ID
    Public SalManNam As String  '业代名称
    Public OutNum As String     '客户ID
    Public OutNam As String     '客户名称
    Public ActID As String      '活动ID
    Public ActNam As String     '活动名称
End Class

'史永平添加
Public Class DisplayItemList
    '待检查活动项目及图片列表
    Public ChkDoc As String     '检查表号
    Public CheckMon As String   '检查期间
    Public SalSupNum As String  '主任ID
    Public SalSupNam As String  '主任名称
    Public SalManNum As String  '业代ID
    Public SalManNam As String  '业代名称
    Public OutNum As String     '客户ID
    Public OutNam As String     '客户名称
    Public ActID As String      '活动ID
    Public ActNam As String     '活动名称
    Public ItemBH As String     '检查项目号
    Public ItemDesc As String   '检查项目内容
    Public Photo As String      '照片
    Public CreateUser As String '创建用户
    Public CreateTime As String '创建时间
End Class

''史永平添加 
Public Class DisplayActItemListNoPhoto
    '待检查活动项目及图片列表 
    Public ChkDoc As String '检查表号 
    Public CheckMon As String '检查期间 
    Public SalSupNum As String '主任ID 
    Public SalSupNam As String '主任名称 
    Public SalManNum As String '业代ID 
    Public SalManNam As String '业代名称 
    Public OutNum As String '客户ID 
    Public OutNam As String '客户名称 
    Public ActID As String '活动ID 
    Public ActNum As String '活动编号 
    Public ItemBH As String '检查项目号 
    Public ItemDesc As String '检查项目内容 
End Class
