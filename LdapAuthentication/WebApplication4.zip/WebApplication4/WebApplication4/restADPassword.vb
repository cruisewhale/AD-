﻿Imports System
Imports System.Text
Imports System.Collections
Imports System.DirectoryServices

Namespace ADusers
    Public Class restADPassword

        Public Function RestPassword(ByVal username As String) As Boolean
            'userName 只能包含用户名,不要加前缀:cccil\
            Dim result As Boolean
            Dim directoryEntry = GetDirectoryEntryByUserName(username)

            If directoryEntry IsNot Nothing Then

                Try
                    directoryEntry.Invoke("SetPassword", New Object() {"abc123^^"})
                    '注意domain 密码规则
                    directoryEntry.Properties("LockOutTime").Value = 0
                    directoryEntry.Close()
                    result = True

                Catch ex As Exception

                    result = False

                End Try

            Else
                result = False
            End If

            Return result

        End Function

        Public Shared Function GetDirectoryEntryByUserName(userName As String) As DirectoryEntry
            'userName 只能包含用户名,不要加前缀:cccil\
            Dim de = GetDirectoryObject()

            Dim deSerach As New DirectorySearcher(de)
            deSerach.Filter = "(&(objectCategory=Person)(objectClass=user) (SAMAccountName=" & userName & "))"

            Dim Result As DirectoryServices.SearchResult = deSerach.FindOne

            Return If(Result IsNot Nothing, Result.GetDirectoryEntry(), Nothing)


        End Function


        Private Shared Function GetDirectoryObject() As DirectoryEntry
            Dim adminUser As String = "nn00001"         '管理员账号
            Dim adminPassword As String = "nncc!2486"   '管理员密码

            ' Path to your LDAP directory server, 可以通过OU来限制查找范围
            Dim fullPath As String = "LDAP://cccil.com/OU=Users,OU=NNCC,OU=CCCIL Bottlers,OU=CCCIL Global,DC=cccil,DC=com"

            Dim directoryEntry = New DirectoryEntry(fullPath, adminUser, adminPassword, AuthenticationTypes.Secure)
            Return directoryEntry


        End Function


    End Class
End Namespace

